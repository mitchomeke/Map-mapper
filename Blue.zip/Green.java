public interface Green extends Player{

    public static final String PlayerType = "Green";
}
