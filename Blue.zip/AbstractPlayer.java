/**
 * Abstract class representing a Player.
 */

public class AbstractPlayer implements Player {

    /**
     * The name of the PlayerType.
     **/
    private String PlayerType;

    /**
     * The Coordinates of the PLayer.
     **/
    private int Xcoord;
    private int Ycoord;

    /**
     * Constructs an object Player with the given PlayerType and Coordinates.
     *
     * @param PlayerType The Type of the Player.
     * @param Xcoord     & Ycoord The coordinates of the Player.
     */

    protected AbstractPlayer(String PlayerType, int Xcoord, int Ycoord) {
        this.PlayerType = PlayerType;
        this.Xcoord = Xcoord;
        this.Ycoord = Ycoord;
    }

    @Override
    public String getPlayerType() {
        return PlayerType;
    }

    @Override
    public int getRows() {
        return Xcoord;
    }

    @Override
    public int getColumns() {
        return Ycoord;
    }

    @Override
    public void movePlayer(String direction, int x, int y) {
        switch (direction) {
            case "North":
                Ycoord--;
                break;
            case "South":
                Ycoord++;
                break;
            case "East":
                Xcoord++;
                break;
            case "West":
                Xcoord--;
                break;
            default:
                break;
        }
    }

    @Override
    public void setPlayer(int x, int y) {
        this.Xcoord = Xcoord;
        this.Ycoord = Ycoord;

    }

    @Override
    public void attack() {
        //idk how to implement the attack command, cause different player types have different attacks.
        //When attacking, the players of the current team do not move
        //but attack the opposing players in different ways, depending on their type (blue players attacks
        //players in the same horizontal coordinate, green players on the diagonals, and red players in
        //rectangular areas

    }

    @Override
    public void setStatus() {

    }

    /**
     * Checks the equality of the instance with obj.
     * Two Players are considered equal if they have the same PlayerType.
     *
     * @param obj The object to compare with <code>this</code>.
     * @return <code>true</code> if the objects are equal, <code>true</code> otherwise.
     */

    public boolean Equals(Object obj) {
        // If obj is the same as the instance
        if (this == obj)
            return true;

        // If obj is not an instance of AbstractPlayer
        if (!(obj instanceof AbstractPlayer))
            return false;

        // Safe cast of obj to AbstractPlayer
        AbstractPlayer other = (AbstractPlayer) obj;

        // If the PlayerType of the instance is null
        if (PlayerType == null) {
            // If the PlayerType of the other animal is not null
            if (other.PlayerType != null)
                return false;
        }
        // If the PlayerType of the instance is different other Player
        else if (!PlayerType.equals(other.PlayerType)) {
            return false;

            //Otherwise,
        }
        return true;
    }
}