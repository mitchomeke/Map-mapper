public class BunkersIterator implements Iterator<Bunker> {

    private int current;
    private Bunker[][] bunkers;
    private String name;

    public BunkersIterator(Bunker[][] bunkers, String name){
        this.name = name;
        this.bunkers = bunkers;
        searchNext();
    }


    @Override
    public boolean hasNext() {
        return current < bunkers.length;
    }

    @Override
    public Bunker next() {
        Bunker res = bunkers[current++][0];
        searchNext();
        return res;
    }

    private void searchNext(){
        while(hasNext() && !bunkers[current][0].getBunkerName().equals(name))
            current++;
    }
}
