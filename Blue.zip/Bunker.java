public interface Bunker {
    String getBunkerName();
    int getTreasury();
    void CreatePlayer(String PlayerType);
    boolean hasPlayersatPosition(int index);
    boolean Empty(int index);
    int getXcoordinate();
    int getYcoordinate();
    boolean hasPlayers();
    boolean hasPlayer(int x, int y);



}
