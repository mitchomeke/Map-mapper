public class RedClass extends AbstractPlayer implements Red {
    public RedClass(String PlayerType, int Xcoord, int Ycoord) {
        super(PlayerType, Xcoord, Ycoord);
    }
}
