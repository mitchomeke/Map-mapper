public class TeamClass implements Team{
    private static final int DEFAULT = 10;
    Player player;
    String TeamName;
    String BunkerName;
    Array<Bunker> bunkers;
    int numofBunkers;
    Array<Player> players;
    int numofPlayers;
    String PlayerType;
    int xCoord;
    int yCoord;
    Bunker bunker;
    public TeamClass(String TeamName, String BunkerName){
        this.TeamName = TeamName;
        this.BunkerName = BunkerName;
        bunkers = new ArrayClass<>();
        numofBunkers = 0;
        players = new ArrayClass<>();
        numofPlayers = 0;
    }

    @Override
    public boolean hasAnyBunker(){
        return bunkers.get(0) != null;
    }

    @Override
    public boolean hasBunker(String BunkerName){
        int integer = 0;
        boolean found = true;
        bunker = bunkers.get(integer);
        while (!bunker.getBunkerName().equals(BunkerName) && found){
            found = false;
            bunker = bunkers.get(integer++);
        }if (bunker.getBunkerName().equals(BunkerName) && !found){
            found = true;
        }
        return found;
    }

    @Override
    public String getTeamName() {
        return TeamName;
    }

    @Override
    public int getNumOfBunkers() {
        return numofBunkers;
    }

    @Override
    public String getBunkerName() {
        return BunkerName;
    }

    @Override
    public Iterator<Bunker> ListBunkers() {
        return new BunkersIterator(bunkers,BunkerName);

    }
    @Override
    public boolean hasPlayersatPosition(int x, int y){
        boolean found = true;
        int integer = 0;
        player = players.get(integer);
        while (player.getRows() != x && player.getColumns() != y && found){
            found = false;
            player = players.get(integer++);
        } if (player.getRows() == x && player.getColumns() == y && !found){
            found = true;
        }
        return found;
    }
    @Override
    public Bunker getBunkeratPosition(int x, int y){
        int integer = 0;
        bunker = bunkers.get(integer);
            while (bunker.getXcoordinate() != x && bunker.getYcoordinate() != y){
                bunker = bunkers.get(integer++);
        }
            return bunker;
}

    @Override
    public void addBunker(Bunker bunker) {
        bunkers.insertLast(bunker);
        numofBunkers++;
    }

    @Override
    public void removeBunker(int position){
        bunkers.removeAt(position);
        numofBunkers--;
    }
    @Override
    public void addPlayer(Player player){
        players.insertLast(player);
        numofPlayers++;
        //We check the type of player and add to the team
        /*if (numofPlayers >= Players.length) {
            resize();
        }
            if (player instanceof RedClass){
                    Players[numofPlayers] = player;
        }
            else if (player instanceof BlueClass){
                    Players[numofPlayers] = player;
            } else if (player instanceof GreenClass) {
                    Players[numofPlayers] = player;
            }
            numofPlayers++;
        }*/
    }

    @Override
    public Iterator<Player> ListPlayers() {
        return new PlayerIterator(players,PlayerType);
    }

    @Override
    public int getNumOfPlayers() {
        return numofPlayers;
    }
    @Override
    public Player players(){
        return new AbstractPlayer(PlayerType,xCoord,yCoord);
    }

    @Override
    public void removePlayer(Player player) {
        int pos =players.searchIndexOf(player);
        players.removeAt(pos);
        numofPlayers--;
        }

    @Override
    public Player getPlayerByPosition(int x, int y){
        int integer = 0;
        player = players.get(integer);
        while(player.getRows() != x && player.getColumns() != y){
            player = players.get(integer++);
        }
        return player;
    }

    @Override
    public boolean PlayerMoveOff(int x, int y){
        //when the player is moving off the map,don´t know how.
        return false;
    }

    @Override
    public Bunker getLastBunker() {
        return bunkers.get(bunkers.size());
    }

    @Override
    public boolean isActive() {
        return getNumOfBunkers() > 0 && getNumOfPlayers() > 0;
    }
}
