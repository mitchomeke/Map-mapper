class GreenClass extends AbstractPlayer implements Green{

    public GreenClass(String PlayerType, int Xcoord, int Ycoord) {
        super(PlayerType, Xcoord, Ycoord);
    }
}
