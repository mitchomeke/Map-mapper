public interface Red extends Player{
    public static final String PlayerType = "Red";
}
