public interface Array<M>{

    /**
     * Inserts an element at the last position of the array.
     * @param m the element to insert
     * @pre m != null
     */
    void insertLast(M m);

    /**
     * Inserts an element at the specified position in the array.
     *
     * @param m   the element to insert
     * @param pos the position at which to insert the element
     * @pre m != null && 0 <= pos && pos <= size()
     */
    void insertAt(M m, int pos);

    /**
     * Removes the last element from the array.
     * @pre size() > 0
     */
    void removeLast();

    /**
     * Removes the element at the specified position from the array.
     * @param pos the position of the element to remove
     * @pre pos >= 0 && pos < size()
     */
    void removeAt(int pos);

    /**
     * Searches for the specified element in the array in forward direction.
     * @param m the element to search for
     * @return true if the element is found, false otherwise
     * @pre m != null
     */
    boolean searchForward(M m);

    /**
     * Searches for the specified element in the array in backward direction.
     * @param m the element to search for
     * @return <code>true</code> if the element is found, <code>false</code> otherwise
     * @pre m != null
     */
    boolean searchBackward(M m);

    /**
     * Searches for the positions of the specified element in the array.
     * @param m the element to search for
     * @return the index of the element if found, <code>-1</code> otherwise
     * @pre m != null
     */
    int searchIndexOf(M m);

    /**
     * Retrieves the element at the specified position in the array.
     * @param pos the position of the element to retrieve
     * @return the element at position <code>pos</code>
     * @pre pos >= 0 && pos < size()
     */
    M get(int pos);

    /**
     * Returns the number of elements in the array.
     * @return the number of elements in the array
     */
    int size();

    /**
     * Returns an iterator over the elements in the array.
     * @return an iterator
     */
    Iterator<M> iterator();


}
