public interface Cell {
    int getRow();
    int getColumn();
    boolean equals(Object o);
}
