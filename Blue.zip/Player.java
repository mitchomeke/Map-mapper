public interface Player {
    public String getPlayerType();
    public int getRows();
    public int getColumns();
    void movePlayer(String direction, int x, int y);
    void setPlayer(int x,int y);
    void attack();
    void setStatus();
}
