class CellClass implements Cell{
    private int row;
    private int column;
    Bunker bunker;
    Player player;


    CellClass(){

    }
    @Override
    public int getRow() {
        return row;
    }
    @Override
    public int getColumn() {
        return column;
    }

}
