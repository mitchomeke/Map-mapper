public class PlayerIterator implements Iterator<Player>{
    
    private int current;
    Array<Player> players;
    private String playerType;

    public PlayerIterator(Array<Player> players, String playerType){
        this.players = players;
        this.playerType = playerType;
        searchNext();
    }
    private void searchNext(){
        while (hasNext() && !rightPlayer(players.get(current)))
            current++;
    }

    private boolean rightPlayer(Player player) {
        if (playerType.equalsIgnoreCase(Red.PlayerType))
            return (player instanceof Red);
        if (playerType.equalsIgnoreCase(Blue.PlayerType))
            return (player instanceof Blue);
        if (playerType.equalsIgnoreCase(Green.PlayerType))
            return (player instanceof Green);
        else
            return false;
    }

    @Override
    public boolean hasNext() {
        return current < players.size();
    }

    @Override
    public Player next() {
        Player res = players.get(current++);
        searchNext();
        return res;
    }
}
