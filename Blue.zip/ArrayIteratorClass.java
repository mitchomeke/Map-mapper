public class ArrayIteratorClass<M> implements Iterator<M>{

    private int counter;

    private int current;

    private M[] elems;

    public ArrayIteratorClass(M[] elems, int counter){
        this.elems = elems;
        this.counter = counter;
        current = 0;
    }
    @Override
    public boolean hasNext() {
        return current < counter;
    }

    @Override
    public M next() {
        return elems[current++];
    }
}
