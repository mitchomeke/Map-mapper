public class TeamsIterator implements Iterator<Team> {

    private int current;

    private Array<Team> teams;
    private String name;

    public TeamsIterator(Array<Team> teams, String name){
        this.teams = teams;
        this.name = name;
        searchNext();
    }
    @Override
    public boolean hasNext() {
        return current < teams.size();
    }

    @Override
    public Team next() {
        Team res = teams.get(current++);
        searchNext();
        return res;
    }

    private void searchNext(){
        while (hasNext() && !teams.get(current).getTeamName().equals(name))
            current++;
    }
}
