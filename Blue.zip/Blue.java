public interface Blue extends Player{
    public static final String PlayerType = "Blue";
}
