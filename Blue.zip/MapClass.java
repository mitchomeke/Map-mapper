class MapClass implements Map{
    Cell[][] cells;
    private final int DEFAULT = 10;
    private final String BLUE = "BLUE";
    private final String GREEN = "GREEN";
    private final String RED = "RED";
    private Array<Team> teams;
    private int maxRows;
    private int maxColumns;
    char grid[][];
    Bunker[][] bunkers;
    Bunker bunker;
    int numofbunkers;
    int Treasury;
    String BunkerName;
    String TeamName;
    int Numofteams;
    Team team;
    private Team team1;
    private Team team2;
    private Team currentTeam;
    public int currentTeamIndex;
    Array<Player> players;
    String playerType;
    int xcoordinate;
    int ycoordinate;



     MapClass(){
        this.maxRows = maxRows;
        this.maxColumns = maxColumns;
        grid = new char[maxRows][maxColumns];
        numofbunkers = bunkers.length;
        teams = new ArrayClass<>();
        bunkers = new Bunker[xcoordinate][ycoordinate];
    }


    @Override
    public boolean CreateGrid(int maxRows,int maxColumns) {
        if (maxRows >= 10 && maxColumns >= 10) {
            for (int i = 0; i < maxRows; i++) {
                for (int j = 0; j < maxColumns; j++) {
                    grid[i][j] = '.';
                }

            }
            return true;
        }
        return false;
    }

    @Override
    public int getRows() {
        return maxRows;
    }

    @Override
    public int getColumns() {
        return maxColumns;
    }

    @Override
    public void addBunker(int xCoordinate,int yCoordinate, int Treasury, String BunkerName){
        if (canfitWithinDimensions() && !BunkerExists(BunkerName)){
            resize();
            for (int i = 0; i < bunkers.length;i++){
                for (int j = 0; j < bunkers[i].length;j++){
                    if (bunkers[i][j] == null){
                        bunkers[i][j] = new BunkerClass(i,j,Treasury,BunkerName);
                        numofbunkers++;
                        break;
        }

            }

            }
        }
    }

    private boolean canfitWithinDimensions() {
         for (Cell cell : cells){
             if (cell.getRow() > maxRows -1 || cell.getColumn() > maxColumns -1){
                 return false;
             }
         }
        return true;
    }

    @Override
    public int getNumberOfBunkers() {
        return numofbunkers;
    }

    @Override
    public int getNumberOfTeams() {
        return Numofteams;
    }
    @Override
    public boolean addTeam(String TeamName,String BunkerName){
         boolean found = true;
         int integer = 0;
         teams.get(integer);
         while (teams.get(integer).getTeamName().equals(TeamName) && !BunkerExists(BunkerName) && equalsBunker(teams.get(integer)) && found){
             found = false;
             teams.get(integer++);
         }if (teams.get(integer).getTeamName().equals(TeamName) && BunkerExists(BunkerName) && !equalsBunker(teams.get(integer)) && !found){
             found = true;
             team = teams.get(integer);
        }
         teams.insertLast(team);
         Numofteams++;
         return found;
         /*teams.searchForward(team);
        for (int i = 0; i < teams.size();i++){
            if (team.getTeamName().equals(TeamName) && !BunkerExists(BunkerName) && equalsBunker(team)){
                return false;
            }
            teams.insertLast(team);
    }
        Numofteams++;
        return true;
    }
    */
    }
    @Override
    public boolean equalsBunker(Team otherTeam) {
        return BunkerName.equals(otherTeam.getBunkerName());
    }

    @Override
    public Team team() {
        return new TeamClass(TeamName,BunkerName);
    }

    @Override
    public Team getTeamatIndex(int index) {
         return teams.get(index);
    }

    @Override
    public String ListMap(){
// i don´t know how to find the current player
        currentTeam = (currentTeam == team1) ? team1:team2;
        String mapString = "";
            for (int i = 0; i < grid.length;i++){
                for (int j = 0; j < grid[i].length;j++){
                    if (!(bunker.hasPlayersatPosition(i) || bunker.hasPlayersatPosition(j))){
                        mapString += 'B';
                    }
                    else if (!bunker.Empty(i) || !bunker.Empty(j)){
                        mapString += 'O';
                    }
                    else if (currentTeam.hasPlayersatPosition(i,j) || currentTeam.hasPlayersatPosition(i,j)){
                        mapString += 'P';
                    }
                    else {
                        mapString += '.';
                    }
                }
            }
            return mapString;
    }

    @Override
    public void MoveToNextTeam() {
        currentTeamIndex++;
        Team nextTeam = teams.get(currentTeamIndex);
    }

    @Override
    public boolean BunkerExists(String BunkerName) {
        for (int i = 0; i < bunkers.length; i++) {
            for (int j = 0; j < bunkers[i].length; j++) {
                if (bunkers[i][j].getBunkerName().equals(BunkerName)) {
                    return true;
                }
            }

        }
        return false;
    }

    @Override
    public Bunker getBunkerwithName(String BunkerName) {
         if (BunkerExists(BunkerName)){
             return bunker;
         }
        return null;
    }

    @Override
    public boolean isValidType(String PlayerType) {
        return PlayerType.equals(BLUE) || PlayerType.equals(GREEN) || PlayerType.equals(RED);
    }

    @Override
    public Bunker getBunkerByPosition(int x, int y) {
         for (int i = 0; i < numofbunkers;i++){
             for (int j = i; j < bunkers[i].length;j++){
                 if (bunkers[i][j].getXcoordinate() == x && bunkers[i][j].getYcoordinate() == y){
                     bunker = bunkers[i][j];
                 }
             }
         }
         return bunker;
    }

    @Override
    public Team getTeamByName(String TeamName) {
        int integer = 0;
        boolean found = true;
        team = teams.get(integer);
        while (!team.getTeamName().equals(TeamName) && found){
            found = false;
            team = teams.get(integer++);
        }if (team.getTeamName().equals(TeamName) && !found){
            found = true;
        }
        return team;
    }

    @Override
    public Iterator<Team> allTeams() {
        return new TeamsIterator(teams,TeamName);
    }

    @Override
    public Iterator<Bunker> allBunkers(String TeamName) {
        return new BunkersIterator(bunkers,BunkerName);
    }

    @Override
    public Iterator<Player> allPlayers(String TeamName) {
        return new PlayerIterator(players,playerType);
    }


    private void resize() {
        Bunker[][] tmp = new Bunker[bunkers.length+1][];
            for (int i = 0; i < bunkers.length;i++){
                for (int j = 0; j < bunkers[i].length;j++)
                tmp[i][j] = bunkers[i][j];
        }
        bunkers = tmp;
    }

            }
    /*
    the valid horizontal coordinates vary
between 1 and 10 and the vertical vary between 1 and 20
    */
