import java.util.Scanner;

public class Main {
    //commands for usage
    private static final String game = "GAME";
    private static final String quit = "QUIT";
    private static final String help = "HELP";
    private static final String create = "CREATE";
    private static final String attack = "ATTACK";
    private static final String status = "STATUS";
    private static final String map = "MAP";
    private static final String bunkers = "BUNKERS";
    private static final String players = "PLAYERS";
    private static final String move = "MOVE";
    private static final String end = "BYE";
    private static final String error = "ERROR";
    //display commands
    private static final String Game = "game - Create a new game";
    private static final String Help = "help - Show available commands";
    private static final String Quit = "End program execution";
    private static final String Create = "Create a player in a bunker";
    private static final String Attack = "Attack with all players of the current team";
    private static final String Map = "Show the map of the current team";
    private static final String Bunkers = "List the bunkers of the current team, by the order they were seized";
    private static final String Players = "List the active players of the current team, by the order they were created";
    private static final String Status = "Show the current state of the game";
    private static final String Move = "Move a player";
    private static final String BUNKER_NOT_CREATED = "Bunker not created.";
    private static final String TEAM_NOT_CREATED = "Team not created.";
    private static final String FATAL_ERROR = "FATAL ERROR: Insufficient number of teams.";
    private static final String NO_OWNER = "without owner";
    private static final String NON_EXISTENT_PLAYER_TYPE = "Non-existent player type.";
    private static final String NON_EXISTENT_BUNKER = "Non-existent bunker.";
    static int currentTeamIndex;
    //some constants
    private static final String SOUTH = "South";
    private static final String NORTH = "North";
    private static final String WEST = "West";
    private static final String EAST = "East";


    public static void main(String[] args) {
        getCommand();
    }
    private static void getCommand(){
        Scanner in = new Scanner(System.in);
        String command = in.nextLine().toUpperCase();
        Map mapper = new MapClass();

        if (!isGameOver(mapper)){
            do {
                System.out.println("teamName>" + command);
                switch (command) {
                    case game -> startGame(in, mapper);
                    case attack -> fight(in,mapper);
                    case map -> ListMap(mapper);
                    case status -> GameStatus(mapper);
                    case help -> displayCommands(mapper);
                    case bunkers -> ListBunkers(mapper);
                    case players -> ListPlayers(mapper);
                    case move -> PlayerMove(in,mapper);
                    case create -> CreatePlayer(in, mapper);
                    case quit -> System.out.println(end);
                    default -> System.out.println(error);
                }
            } while (!command.equals(quit));
            in.close();
    }
        else {
            do {
                System.out.println(">" + command);
                switch (command) {
                    case game -> startGame(in, mapper);
                    case help -> displayCommands(mapper);
                    case quit -> System.out.println(end);
                    default -> System.out.println(error);
                }
                } while (!command.equals(quit)) ;{
                in.close();
            }
        }}

    private static void CreatePlayer(Scanner in, Map mapper) {
        //the command is successful if the current team has the bunker
        String PlayerType = in.next().toUpperCase();
        String BunkerName = in.next();

        //we have to find the current team
        Team currentTeam = mapper.getTeamatIndex(currentTeamIndex);
        if (!PlayerType.equals("Red") && !PlayerType.equals("Blue") && !PlayerType.equals("Green")) {
            System.out.println(NON_EXISTENT_PLAYER_TYPE);


        }
        Bunker bunker = mapper.getBunkerwithName(BunkerName);
            if (currentTeam.hasBunker(BunkerName) && mapper.BunkerExists(BunkerName)) {
                if (!bunker.hasPlayers() && bunker.getTreasury() >= PaymentCalculation(PlayerType)) {
                    bunker.CreatePlayer(PlayerType);
                    System.out.println(PlayerType + " player created in " + BunkerName);
                }
                if (!mapper.BunkerExists(BunkerName)){
                    System.out.println(NON_EXISTENT_BUNKER);
                }
                if (mapper.BunkerExists(BunkerName) && !currentTeam.hasBunker(BunkerName)){
                    System.out.println("Bunker illegally invaded.");
                }//if the bunker belongs to the current team but is occupied with a player from the same team.
                if (currentTeam.hasBunker(BunkerName) && bunker.hasPlayers()){
                    System.out.println("Bunker not Free");
                }
                if (currentTeam.hasBunker(BunkerName) && bunker.getTreasury() < PaymentCalculation(PlayerType)){
                    System.out.println("Insufficient coins for recruitment");
                }
                mapper.MoveToNextTeam();
                System.out.println(currentTeam.getTeamName() + ">");
            } else if (!mapper.isValidType(PlayerType)){
                System.out.println("Non-existent player type.");
            }

        }
//all bunkers generate a coin as it is the end of a turn
    private static void PlayerMove(Scanner in, Map mapper){
        int Xcoordinate = in.nextInt();
        int Ycoordinate = in.nextInt();
        String dir = null;
        //current team´s team
        Team currentTeam = mapper.getTeamatIndex(currentTeamIndex);
        //other team´s team
        Team team1 = mapper.team();
        //other team´s last bunker
        Bunker bunkaa = team1.getLastBunker();
        //other team´s bunker
        Bunker bunker = team1.getBunkeratPosition(Xcoordinate,Ycoordinate);
        //current team´s player
        Player player = currentTeam.getPlayerByPosition(Xcoordinate,Ycoordinate);
        //abandoned bunker
        Bunker bunka = mapper.getBunkerByPosition(Xcoordinate,Ycoordinate);

        if (Xcoordinate > mapper.getRows() || Ycoordinate > mapper.getColumns()){
            System.out.println("Invalid position");
        }
            if (!player.getPlayerType().equals("Red")) {
                for (int i = 0; i < 3; i++) {
                    dir = in.next();
                    if (!IsValidDirection(dir)) {
                        System.out.println("Invalid direction. ");
                        return;
                    }
                }
                System.out.println("Invalid move.");
                return;
            }
                for (int i = 0; i < 3;i++){
                    dir = in.next();
                    if (IsValidDirection(dir)){
                        player.movePlayer(dir,Xcoordinate,Ycoordinate);
                        player.setPlayer(Xcoordinate,Ycoordinate);
                        System.out.println(player.getPlayerType() + " player in position " + "("+Xcoordinate + ", " + Ycoordinate+")");
                    }
                    else {
                        System.out.println("Invalid direction.");
                    }
                    //if it´s not a red player and three moves have been specified, then "Invalid Move
                }
                if (player.getPlayerType().equals("Green") || player.getPlayerType().equals("Blue")){
                    dir = in.next();
                    if (IsValidDirection(dir)){
                        player.movePlayer(dir,Xcoordinate,Ycoordinate);
                        player.setPlayer(Xcoordinate,Ycoordinate);
                        System.out.println(player.getPlayerType() + " player in position " + "("+Xcoordinate + ", " + Ycoordinate+")");
                    }
                    else {
                        System.out.println("Invalid direction.");
                    }
                }
                else if (!currentTeam.hasPlayersatPosition(Xcoordinate,Ycoordinate)) {
                    System.out.println("No player in that position.");
                }
                else if (currentTeam.hasPlayersatPosition(Xcoordinate,Ycoordinate)){
                    System.out.println("Position occupied.");
                }
                else if (currentTeam.PlayerMoveOff(Xcoordinate,Ycoordinate)){
                    System.out.println("Trying to move off the map.");
                    if (player.getPlayerType().equals("Red")){
                        player.movePlayer(dir,Xcoordinate,Ycoordinate);
                        player.setPlayer(Xcoordinate,Ycoordinate);
                    }
                }//if the player tries to move to a position occupied by an abandoned bunker

            if (!bunka.hasPlayers()){
                player.movePlayer(dir,Xcoordinate,Ycoordinate);
                player.setPlayer(Xcoordinate,Ycoordinate);
                currentTeam.addBunker(bunka);
                System.out.println("Bunker seized.");
                System.out.println(player.getPlayerType() + " player in position " + "("+player.getRows()+", "+player.getColumns()+")");
            }//if there´s another player at that position, a fight is initiated.
            Player player1 = team1.getPlayerByPosition(Xcoordinate,Ycoordinate);
            if (player.getPlayerType().equals("Red") && player1.getPlayerType().equals("Blue") || player.getPlayerType().equals("Blue") && player1.getPlayerType().equals("Green") || player.getPlayerType().equals("Green") && player1.getPlayerType().equals("Red") || player.getPlayerType().equals("Red") && player1.getPlayerType().equals("Red") || player.getPlayerType().equals("Blue") && player1.getPlayerType().equals("Blue") || player.getPlayerType().equals("Green") && player1.getPlayerType().equals("Green")){
                team1.removePlayer(player1);
                player.movePlayer(dir,Xcoordinate,Ycoordinate);
                player.setPlayer(Xcoordinate,Ycoordinate);
                System.out.println("Won the fight.");
            }
            else if (player1.getPlayerType().equals("Red") && player.getPlayerType().equals("Blue") || player1.getPlayerType().equals("Blue") && player.getPlayerType().equals("Green") || player1.getPlayerType().equals("Green") && player.getPlayerType().equals("Red") || player1.getPlayerType().equals("Red") && player.getPlayerType().equals("Red") || player1.getPlayerType().equals("Blue") && player.getPlayerType().equals("Blue") || player1.getPlayerType().equals("Green") && player.getPlayerType().equals("Green")){
                currentTeam.removePlayer(player);
                player1.movePlayer(dir,Xcoordinate,Ycoordinate);
                player1.setPlayer(Xcoordinate,Ycoordinate);
                System.out.println("Player eliminated.");
            }
            if (bunker.hasPlayer(Xcoordinate,Ycoordinate)) {
                if (player.getPlayerType().equals("Red") && player1.getPlayerType().equals("Blue") || player.getPlayerType().equals("Blue") && player1.getPlayerType().equals("Green") || player.getPlayerType().equals("Green") && player1.getPlayerType().equals("Red") || player.getPlayerType().equals("Red") && player1.getPlayerType().equals("Red") || player.getPlayerType().equals("Blue") && player1.getPlayerType().equals("Blue") || player.getPlayerType().equals("Green") && player1.getPlayerType().equals("Green")) {
                    team1.removePlayer(player1);
                    currentTeam.addBunker(bunker);
                    System.out.println("Won the fight and bunker seized.");
                    player.movePlayer(dir,Xcoordinate,Ycoordinate);
                    player.setPlayer(Xcoordinate,Ycoordinate);
                    System.out.println(player.getPlayerType() + " player in position " + "("+player.getRows()+", "+player.getColumns()+")");
                }// When the player moves, they seized the last bunker of the last opposing team that no longer had players. In this case, the team of the player who carries out the attack wins the game.
            } else if (!bunkaa.hasPlayers() && bunkaa.getYcoordinate() == Ycoordinate && bunkaa.getXcoordinate() == Xcoordinate && mapper.getNumberOfTeams() == 2){
                player.movePlayer(dir,Xcoordinate,Ycoordinate);
                player.setPlayer(Xcoordinate,Ycoordinate);
                currentTeam.addBunker(bunkaa);
                System.out.println("Winner is " + currentTeam.getTeamName());
                isGameOver(mapper);
                //When the player moves, they fight and wins over the last opposing player from the
                //last active opposing team with no bunkers, thus winning the game.
        } else if  (mapper.getNumberOfTeams() ==2 && !team1.hasAnyBunker() && team1.getNumOfPlayers() == 1 && (player.getPlayerType().equals("Red") && player1.getPlayerType().equals("Blue") || player.getPlayerType().equals("Blue") && player1.getPlayerType().equals("Green") || player.getPlayerType().equals("Green") && player1.getPlayerType().equals("Red") || player.getPlayerType().equals("Red") && player1.getPlayerType().equals("Red") || player.getPlayerType().equals("Blue") && player1.getPlayerType().equals("Blue") || player.getPlayerType().equals("Green") && player1.getPlayerType().equals("Green"))){
                team1.removePlayer(player1);
                player.movePlayer(dir,Xcoordinate,Ycoordinate);
                player.setPlayer(Xcoordinate,Ycoordinate);
                if (!team1.isActive()) {
                    System.out.println("Winner is " + currentTeam.getTeamName());
                    isGameOver(mapper);
                    System.out.println(">");
                }
            } else if (currentTeam.getNumOfPlayers() == 1 && !currentTeam.hasAnyBunker() && mapper.getNumberOfTeams() == 2 && (player1.getPlayerType().equals("Red") && player.getPlayerType().equals("Blue") || player1.getPlayerType().equals("Blue") && player.getPlayerType().equals("Green") || player1.getPlayerType().equals("Green") && player.getPlayerType().equals("Red") || player1.getPlayerType().equals("Red") && player.getPlayerType().equals("Red") || player1.getPlayerType().equals("Blue") && player.getPlayerType().equals("Blue") || player1.getPlayerType().equals("Green") && player.getPlayerType().equals("Green"))){
                currentTeam.removePlayer(player);
                player1.movePlayer(dir,Xcoordinate,Ycoordinate);
                player1.setPlayer(Xcoordinate,Ycoordinate);
                //the resulting team becomes inactive
                if (!currentTeam.isActive()){
                    System.out.println("Winner is " + team1.getTeamName());
                    isGameOver(mapper);
                    System.out.println(">");
                    }

                }
            mapper.MoveToNextTeam();
            System.out.println(currentTeam.getTeamName()+">");
            }
        private static boolean IsValidDirection(String direction){
        return direction.equals(NORTH) || direction.equals(SOUTH) || direction.equals(EAST) || direction.equals(WEST);
        }
    private static void GameStatus(Map mapper) {
        System.out.println(mapper.getRows() + mapper.getColumns());
        int bunkersNumber = mapper.getNumberOfBunkers();
        System.out.println(bunkersNumber + "bunkers:");
        Iterator<Team> it = mapper.allTeams();
        while (it.hasNext()) {
            Team team = it.next();
            System.out.println(team.getBunkerName() + (team.getTeamName()));
            //we use a list here to list the bunkers

            // we use the team iterator here i think, so while it.hasNext we return a team as next, if those teams have bunkers, we continue the code
            while (team.hasAnyBunker()) {
                int teamNumber = mapper.getNumberOfTeams();
                System.out.println(teamNumber + "teams:");
                for (int i = 0; i < teamNumber; i++) {
                    System.out.println(mapper.getTeamatIndex(i) + ";");
                    //we use a list here to list the teams
                }
                System.out.println(mapper.getTeamatIndex(currentTeamIndex) + ">");
            }
        }

            /*
            The player may have to fight if the bunker is occupied by an opposing player. In this case,
they only seize the bunker if they win the fight.
             */

            /*
            The
game ends when there is only one active team left.

             */
    }
    private static void fight(Scanner in, Map mapper){
        String TeamName = in.nextLine();
        Team team = mapper.getTeamByName(TeamName);
        Team CurrentTeam = mapper.getTeamatIndex(currentTeamIndex);

        //I HAVENT DONE THE FIGHT COMMAND.

        //When attacking, the players of the current team do not move
        //but attack the opposing players in different ways, depending on their type (blue players attacks
        //players in the same horizontal coordinate, green players on the diagonals, and red players in
        //rectangular areas

            /*
            Note that, in each fight the current team can become inactive (if the
team loses all bunkers and all its players), or the game ends (only one team remains active).
             */
    }
    private static boolean startGame(Scanner in, Map mapper){
        int width = in.nextInt();
        int height = in.nextInt();
        int numofteams = in.nextInt();
        int numofbunkers = in.nextInt();
        if (mapper.getNumberOfTeams() < 2 || mapper.getNumberOfTeams() > 8 || !isGameOver(mapper)){
            return false;
        }
        mapper.CreateGrid(width,height);
        if (numofbunkers >= numofteams){
            System.out.println(numofbunkers + "bunkers:");
            for (int i = 0; i < numofbunkers;i++){
                    int xCoordinate = in.nextInt();
                    int yCoordinate = in.nextInt();
                    int treasure = in.nextInt();
                    String bunkerName = in.next();
                    if (treasure > 0){
                        mapper.addBunker(xCoordinate,yCoordinate,treasure,bunkerName);
                    }
                    System.out.println(BUNKER_NOT_CREATED);
                    return false;
                }
            }
        else {
            return false;
        }
            System.out.println(numofteams + "teams:");
            for (int i = 0; i < numofteams; i++){
                String teamName = in.next().trim();
                String bunkerName = in.nextLine();
                if(mapper.addTeam(teamName,bunkerName)){
                    if (i == 0){
                        System.out.println(teamName + ">");
                }
                } else if (!mapper.addTeam(teamName,bunkerName)) {
                    System.out.println(TEAM_NOT_CREATED);
                } else if (numofteams < 2) {
                    System.out.println(FATAL_ERROR);
                } else if (!isGameOver(mapper) && (!mapper.addTeam(teamName,bunkerName) || numofteams < 2 || mapper.getNumberOfTeams() < 2 || mapper.getNumberOfTeams() > 8)) {
                    isGameOver(mapper);

                }
            }
            return true;
        }

    private static boolean isGameOver(Map mapper) {
        return mapper.getNumberOfTeams() == 1;
    }

    private static void displayCommands(Map mapper){
        if (isGameOver(mapper)){
            System.out.println(Game);
            System.out.println(Help);
            System.out.println(Quit);
        }else {
            System.out.println(Game);
            System.out.println(Move);
            System.out.println(Create);
            System.out.println(Attack);
            System.out.println(Status);
            System.out.println(Map);
            System.out.println(Bunkers);
            System.out.println(Players);
            System.out.println(Quit);
        }

    }
    private static String ListMap(Map mapper) {
        System.out.println(mapper.getRows() + mapper.getColumns());
        return mapper.ListMap();
    }
    private static void ListBunkers(Map mapper){
        Team currentTeam = mapper.getTeamatIndex(currentTeamIndex);
        //lists the name treasury and location of all bunkers in the current team
        int bunkers = currentTeam.getNumOfBunkers();
        if (bunkers == 0){
            System.out.println("Without bunkers");
        }
        if (bunkers > 0){
            System.out.println(bunkers + "bunkers:");
            Iterator<Bunker> it = mapper.allBunkers(currentTeam.getTeamName());
            while (it.hasNext()){
                Bunker bunker = it.next();
                System.out.println(bunker.getBunkerName() + "with " + bunker.getTreasury() + " coins in position " +"(" + bunker.getXcoordinate() + "," + bunker.getYcoordinate()+ ")");
            }
        }
        }
    private static void ListPlayers(Map mapper){
        Team currentTeam = mapper.getTeamatIndex(currentTeamIndex);
        //we list out the players of the current team, how to find current team.
        int numofplayers = currentTeam.getNumOfPlayers();
        if (numofplayers == 0){
            System.out.println("Without Players");
        }
        Iterator<Player> it = mapper.allPlayers(currentTeam.getTeamName());
        while (it.hasNext()){
            System.out.println(currentTeam.players().getPlayerType() + " player in position " +  "(" + currentTeam.players().getRows() + "," + currentTeam.players().getColumns() +")");
        }

    }
    private static int PaymentCalculation(String PlayerType){
        int Payment = 0;

        if (PlayerType.equals("Blue")){
            Payment = 2;
        }
        if (PlayerType.equals("Green")){
            Payment = 2;
        }
        if (PlayerType.equals("Red")){
            Payment = 4;
        }
        return Payment;
    }


}