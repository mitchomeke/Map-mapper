class BlueClass extends AbstractPlayer implements Blue{
    public BlueClass(String PlayerType, int Xcoord, int Ycoord) {
        super(PlayerType, Xcoord, Ycoord);
    }
}
