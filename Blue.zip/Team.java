public interface Team {
    boolean hasAnyBunker();
    boolean hasBunker(String BunkerName);
    String getTeamName();
    int getNumOfBunkers();
    String getBunkerName();
    Iterator<Bunker> ListBunkers();
    boolean hasPlayersatPosition(int x, int y);
    Bunker getBunkeratPosition(int x, int y);
    void addBunker(Bunker bunker);
    void removeBunker(int i);
    void addPlayer(Player player);
    Iterator<Player> ListPlayers();
    int getNumOfPlayers();
    Player players();
    void removePlayer(Player player);
    Player getPlayerByPosition(int x, int y);
    boolean PlayerMoveOff(int x, int y);
    Bunker getLastBunker();
    boolean isActive();



    /*
    Note that it may happen that one of the teams
is left without players and bunkers, which means that team becomes inactive in the game.
     */
}
/*
If a team’s player moves to a position containing a bunker, they seize the bunker for their
team, regardless of the bunker being abandoned or belonging to another team.

 */