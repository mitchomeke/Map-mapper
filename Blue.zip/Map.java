public interface Map {

    boolean CreateGrid(int maxRows, int maxColumns);
    int getRows();
    int getColumns();
    void addBunker(int xCoordinate,int yCoordinate,int Treasury,String BunkerName);
    int getNumberOfBunkers();
    int getNumberOfTeams();
    boolean addTeam(String TeamName, String BunkerName);
    boolean equalsBunker(Team otherTeam);
    Team team();
    Team getTeamatIndex(int index);
    String ListMap();
    void MoveToNextTeam();
    boolean BunkerExists(String BunkerName);
    Bunker getBunkerwithName(String BunkerName);
    boolean isValidType(String PlayerType);
    Bunker getBunkerByPosition(int x, int y);
    Team getTeamByName(String TeamName);
    Iterator<Team> allTeams();
    Iterator<Bunker> allBunkers(String TeamName);
    Iterator<Player> allPlayers(String TeamName);
}
