class BunkerClass implements Bunker{
    String BunkerName;
    int treasure;
    char coordinates[][];
    int xCoord;
    int yCoord;
    Array<Player> players;
    String PlayerType;
    Player player;


    BunkerClass(int xCoord, int yCoord, int treasure, String BunkerName){
        this.BunkerName = BunkerName;
        coordinates = new char[xCoord][yCoord];
        treasure = 0;
        players = new ArrayClass<>();
    }
    @Override
    public String getBunkerName() {
        return BunkerName;
    }

    @Override
    public int getTreasury() {
        return treasure;
    }


    @Override
    public void CreatePlayer(String PlayerType) {
        while (!hasPlayers()){
            //players are created in an unoccupied bunker of the team (i.e., without any players
            //inside)
                    switch (PlayerType){
                        case "Red":
                            player = new RedClass("Red", player.getRows(),player.getColumns());
                            treasure = treasure -4;
                            break;
                        case "Green":
                            player = new GreenClass("Green", player.getRows(), player.getColumns());
                            treasure = treasure -2;
                            break;
                        case "Blue":
                            player = new BlueClass("Blue", player.getRows(), player.getColumns());
                            treasure = treasure -2;
                            break;
                        default:
                            return;
                    }
                    players.insertLast(player);
                    }
                }
    @Override
    public boolean hasPlayersatPosition(int index) {
        boolean found = true;
        int integer = 0;
        player = players.get(integer);
        while (player.getRows() != index || player.getColumns() != index){
            player = players.get(integer++);
            found = false;
        }if (player.getRows() == index || player.getColumns() == index){
            found = true;
        }
        return found;
    }

    @Override
    public boolean Empty(int index) {
        if (hasPlayersatPosition(index)){
            return false;
        }else {
            return true;
        }
    }

    @Override
    public int getXcoordinate() {
        return xCoord;
    }

    @Override
    public int getYcoordinate() {
        return yCoord;
    }

    @Override
    public boolean hasPlayers(){
        int integer = 0;
        boolean found = true;
        players.get(integer);
        while (players.get(integer) == null && found){
            found = false;
            players.get(integer++);
        }
        if (players.get(integer) != null && !found){
            found = true;
        }
        return found;
    }

    @Override
    public boolean hasPlayer(int x, int y) {
        boolean found = true;
        int integer = 0;
        player = players.get(integer);
        while (player.getRows() != x && player.getColumns() != y && found){
            player = players.get(integer++);
            found = false;
        }if (player.getRows() == x || player.getColumns() == y && !found){
            found = true;
        }
        return found;
}

}
