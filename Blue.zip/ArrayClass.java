
/**
 * This class provides an implementation of the Array interface with a dynamically resizing array.
 * @param <M> the type of elements stored in the array
 */
public class ArrayClass<M> implements Array<M>{
    /**
     * Constants for resizing and searching
     */
    private static final int FACTOR = 2;
    private static final int NOT_FOUND = -1;
    private static final int MAX_ELEMS = 50;

    /**
     * Array to store elements
     */
    private M[] elems;

    /**
     * Counter that maintains the number of elements in the array
     */
    private int counter;

    /**
     * Constructs an empty array with a default maximum capacity.
     */
    @SuppressWarnings("unchecked")
    public ArrayClass() {
        elems = (M[]) new Object[MAX_ELEMS];
        counter = 0;
    }

    /**
     * Constructs an empty array with the specified initial capacity.
     * @param dimension the initial capacity of the array
     */
    @SuppressWarnings("unchecked")
    public ArrayClass(int dimension) {
        elems = (M[]) new Object[dimension];
        counter = 0;
    }
    @Override
    public void insertLast(M m){
        if (counter == elems.length) resize();
        elems[counter++] = m;
    }

    @Override
    public void insertAt(M m, int pos) {
        if (counter == elems.length) resize();
        for(int i = counter-1; i >= pos; i--)
            elems[i+1] = elems[i];
        elems[pos] = m;
        counter++;
    }

    @Override
    public void removeLast() {
        elems[--counter] = null;
    }

    @Override
    public void removeAt(int pos){
        for (int i = pos; i < counter -1;i++){
            elems[pos+1] = elems[pos];
            elems[--counter] = null;
        }
    }

    @Override
    public boolean searchForward(M m) {
       return searchIndexOf(m) != NOT_FOUND;
    }

    @Override
    public boolean searchBackward(M m) {
        boolean found = false;
        for (int i = counter - 1; i <= 0;i--){
            while (!found){
                if (elems[i] == m){
                    found = true;
                }
            }
        }
        return found;
    }

    @Override
    public int searchIndexOf(M m) {
        boolean found = false;
        int result = -1;
        for (int i = 0; i < counter;i++){
            while (!found && result == -1){
                if (elems[i] == m){
                    found = true;
                    result = i;
                }
            }
        }
        return result;
    }

    @Override
    public M get(int pos) {
        return elems[pos];
    }

    @Override
    public int size() {
        return counter;
    }
    private void resize(){
        M tmp[] = (M[]) new Object[FACTOR * elems.length];
        for (int i = 0; i < counter;i++){
            tmp[i] = elems[i];
            elems = tmp;
        }
    }
    @Override
    public Iterator<M> iterator() {
        return new ArrayIteratorClass<M>(elems, counter);
    }



}
